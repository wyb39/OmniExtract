# Document Extraction (Original Prompt) Example

This example demonstrates the **document extraction workflow using the original
prompt**. It extracts a set of multi-property dog-breed traits from AKC breed
standard PDF files in a single batch.

Try it at: https://ngdc.cncb.ac.cn/omniextract/doc-extraction-original

## Files

| File | Description |
|---|---|
| `dog_breed_curation_original.json` | The config file. Load it through the **Config** option on the page to pre-fill the task settings. |
| `dog_breed_files_4_test.zip` | A zip archive of the PDF files used to test extraction. Upload this as the source input. |

The archive contains five sample AKC breed standard PDFs:

- `CB186_akc_standard.pdf`
- `CB194_akc_standard.pdf`
- `CB198_akc_standard.pdf`
- `CB200_akc_standard.pdf`
- `CB204_akc_standard.pdf`

## How to Use

1. Open https://ngdc.cncb.ac.cn/omniextract/doc-extraction-original.
2. Use **Config** to load `dog_breed_curation_original.json`. This populates
   the task name, file type, convert mode, prompt, judging mode, threads, and
   the input/output fields.
3. Upload `dog_breed_files_4_test.zip` as the source files to extract.
4. Run the task and download the result.

## What the Config Contains

`dog_breed_curation_original.json` defines a `multipleEntities` extraction task
named **"dog breed curation"** with:

- `fileType`: `PDF`
- `convertMode`: `wholeDoc`
- `judgingMode`: ``
- `threads`: `6`
- `initialPrompt`: instructs the model to extract only breed-trait values that
  reveal breed features, returning an empty string when information is missing.
- One input field, `Document` (the breed standard text).
- 38 output fields covering physical and behavioral traits, including `size`,
  `color`, `height_at_the_withers`, `weight`, `coat_length`, `head_shape`,
  `eye_color`, `ear_shape`, `tail_curve`, `personality`, and more. See the
  `outputFields` array in the JSON for the full list and each field's
  description.
