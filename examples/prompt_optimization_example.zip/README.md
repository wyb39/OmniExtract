# Prompt Optimization Example

This example demonstrates the **prompt optimization** workflow. It uses a set of
curated dog-breed trait records together with the corresponding AKC breed
standard PDF files to optimize the extraction prompt for better performance.

Try it at: https://ngdc.cncb.ac.cn/omniextract/prompt-optimization

## Files

| File | Description |
|---|---|
| `prompt_optimization_config.json` | The config file. Load it through the **Config** option on the page to pre-fill the task settings. |
| `dataset.json` | The curated dataset (62 records) used to optimize the prompt. Each record contains breed traits plus a `breed_file` field that links to the source PDF. |
| `curated_breed_files.zip` | A zip archive of the 62 curated AKC breed standard PDFs referenced by `dataset.json`. Upload this as the source input. |

## How to Use

1. Open https://ngdc.cncb.ac.cn/omniextract/prompt-optimization.
2. Use **Config** to load `prompt_optimization_config.json`. This populates the
   task name, file type, convert mode, prompt, demos, article field, and the
   input/output fields.
3. Upload `curated_breed_files.zip` as the source files and provide
   `dataset.json` as the curated dataset.
4. Run the task and download the optimized result.

## What the Config Contains

`prompt_optimization_config.json` defines a prompt optimization task named
**"breed prompt optimization"** with:

- `fileType`: `PDF`
- `convertMode`: `wholeDoc`
- `demos`: `1` (number of few-shot examples sampled from the dataset)
- `articleField`: `breed_file` (the field in `dataset.json` that references the
  source document for each record)
- `multipleEntities`: `false`
- `initialPrompt`: instructs the model to extract only breed-trait values that
  reveal breed features, returning an empty string when information is missing.
- One input field, `Document` (the breed standard text).
- 38 output fields covering physical and behavioral traits, including `size`,
  `color`, `height_at_the_withers`, `weight`, `coat_length`, `head_shape`,
  `eye_color`, `ear_shape`, `tail_curve`, `personality`, and more. See the
  `outputFields` array in the JSON for the full list and each field's
  description.

## The Dataset

`dataset.json` is an array of 62 curated records. Each record carries the 38
trait values manually curated from an AKC breed standard, plus bookkeeping
fields:

- `breed_name`: the breed's common name.
- `breed_id`: the breed's identifier (e.g., `CB1`).
- `breed_file`: the name of the source PDF (e.g., `CB1_akc_standard`), which
  matches a PDF inside `curated_breed_files.zip`. This is the field referenced
  by `articleField` in the config.

The optimization uses these curated trait values as the ground truth to refine
the `initialPrompt` into a higher-performing prompt.