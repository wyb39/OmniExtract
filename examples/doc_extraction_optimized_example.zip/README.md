# Document Extraction (Optimized Prompt) Example

This example demonstrates the **document extraction workflow using an optimized
prompt**. Starting from the original dog-breed trait extraction task, it runs a
prompt optimization pass that produces an improved extraction signature and
example demonstrations, then uses them to extract the same multi-property
dog-breed traits from AKC breed standard PDF files.

Try it at: https://ngdc.cncb.ac.cn/omniextract/doc-extraction-optimized

## Files

| File | Description |
|---|---|
| `dog_breed_curation_optimized.json` | The config file. Load it through the **Config** option on the page to pre-fill the task settings. |
| `dog_breed_files_4_test.zip` | A zip archive of the PDF files used to test extraction. Upload this as the source input. |
| `optimization_config.zip` | A zip archive containing the prompt optimization output: `optim_prompt.json` and `optim_settings.json`. See **What the Optimization Contains** below. |

The archive contains five sample AKC breed standard PDFs:

- `CB186_akc_standard.pdf`
- `CB194_akc_standard.pdf`
- `CB198_akc_standard.pdf`
- `CB200_akc_standard.pdf`
- `CB204_akc_standard.pdf`

## How to Use

1. Open https://ngdc.cncb.ac.cn/omniextract/doc-extraction-optimized.
2. Use **Config** to load `dog_breed_curation_optimized.json`. This populates
   the task name, file type, convert mode, judging mode, and threads.
3. Upload `optimization_config.zip` to apply the optimized prompt and
   settings to the task.
4. Upload `dog_breed_files_4_test.zip` as the source files to extract.
5. Run the task and download the result.

## What the Config Contains

`dog_breed_curation_optimized.json` defines a `multipleEntities` extraction
task named **"dog breed curation"** with:

- `fileType`: `PDF`
- `convertMode`: `wholeDoc`
- `judging`: ``
- `threads`: `6`

## What the Optimization Contains

The optimization is driven by two files bundled in `optimization_config.zip`:

- `optim_settings.json` — The optimization settings. It defines the one input
  field, `Document`, and the 38 output fields covering physical and behavioral
  traits (`size`, `color`, `height_at_the_withers`, `weight`, `coat_length`,
  `head_shape`, `eye_color`, `ear_shape`, `tail_curve`, `personality`, and
  more), the `initial_prompt`, the optimization budget (`optim_burden`:
  `medium`), the number of `demos` (`1`), `threads`, and AI-based evaluation
  (`ai_evaluation`).

- `optim_prompt.json` — The optimized output. It contains a generated
  **signature** with detailed per-field instructions and a set of **demos**
  (example extractions with known answers) that the optimizer selected to guide
  the model. Together these form the prompt used for extraction.
