# Table Extraction Example

This example demonstrates the **table extraction** workflow. It extracts
methylation probe data from EWAS (Epigenome-Wide Association Study) tables
attached to a biological article as supplemental materials, in a single batch.

Try it at: https://ngdc.cncb.ac.cn/omniextract/table-parsing

## Files

| File | Description |
|---|---|
| `table_extraction_config.json` | The config file. Load it through the **Config** option on the page to pre-fill the task settings. |
| `ewas_tables_for_test.zip` | A zip archive of the table files used to test extraction. Upload this as the source input. |

The archive contains three supplemental table files (under `test_table_parsing/`)
from article `13229_2018_224`:

- `13229_2018_224_MOESM2_ESM.xlsx`
- `13229_2018_224_MOESM3_ESM.csv`
- `13229_2018_224_MOESM4_ESM.csv`

## How to Use

1. Open https://ngdc.cncb.ac.cn/omniextract/table-parsing.
2. Use **Config** to load `table_extraction_config.json`. This populates the
   task name, file type, classify prompt, extract prompt, threads, and the
   output fields.
3. Upload `ewas_tables_for_test.zip` as the source files to extract.
4. Run the task and download the result.

## What the Config Contains

`table_extraction_config.json` defines a table extraction task named **"ewas
table curation"** with:

- `fileType`: `PDF`
- `threads`: `6`
- `classifyPrompt`: instructs the model to classify whether a table belongs to
  the target categories (DNA differential methylation analysis, EWAS, or DNA
  methylation probes and Mendelian Randomization analysis).
- `extractPrompt`: instructs the model to parse a tab-delimited table of
  methylation probe data, mapping columns exactly as specified, representing
  missing values as `''`, and retaining numerical precision (no rounding).
- 7 output fields describing each probe: `probe_id`, `p_value`,
  `adjusted_p_value`, `delta_beta`, `estimate`, `case_beta`, and `control_beta`.
  See the `outputFields` array in the JSON for each field's description.

Unlike the document extraction workflows, table extraction uses two prompts
instead of a single `initialPrompt`: a `classifyPrompt` to filter target
tables and an `extractPrompt` to parse the selected tables.